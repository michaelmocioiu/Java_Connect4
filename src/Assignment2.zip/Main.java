//Michael Mocioiu 101569108
//Jason Gunawan 101465525
public class Main {
    public static void main(String[] args){
        Game game = new Game();
        game.Launch();

    }
    
}

